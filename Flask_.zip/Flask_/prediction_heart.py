from flask import Flask, request, render_template, jsonify
import pandas as pd


app = Flask(__name__)

# run this cell to import needed packages
import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn import tree
from sklearn.metrics import classification_report
from sklearn import ensemble


import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm

from imblearn.combine import SMOTETomek
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import TomekLinks



data = pd.read_csv("heart_disease_health_indicators_BRFSS2015.csv")
data.info()

y = data['HeartDiseaseorAttack']
X = data.copy()
X = data.drop(columns = ['HeartDiseaseorAttack'])
X.head()

for i in range(21):
    X.iloc[:,i] = (X.iloc[:,i]-np.mean(X.iloc[:,i]))/np.std(X.iloc[:,i])
X.head()

X_ = X.loc[:, ['HighChol', 'GenHlth', 'Age', 'HighBP', 'Smoker', 'Stroke', 'Sex']]

X_train, X_test, y_train, y_test = train_test_split(X_,
                                                    y, 
                                                    test_size=0.3, 
                                                    stratify=y, 
                                                    random_state=42)

X_ = X.loc[:, ['HighChol', 'GenHlth', 'Age', 'HighBP', 'Smoker', 'Stroke', 'Sex']]

## first method 
s= SMOTE()
X_res, y_res= s.fit_resample(X_train, y_train)

lr = LogisticRegression(penalty='l2', C=.1, multi_class='multinomial')
lr.fit(X_res, y_res) 

X_train, X_test, y_train, y_test = train_test_split(X_, y, test_size=0.5, random_state=0)
regr = tree.DecisionTreeClassifier(max_depth=5, random_state=0)
regr.fit(X_res, y_res) 

dtr = ensemble.RandomForestClassifier(min_samples_leaf=15, max_features=7)
rf = dtr.fit(X_res, y_res)

smoke = []
gender = []
stroke = []
bp_ = []
highcol_ = []
genhtlh_ = []
age = []

@app.route("/")
def index():
    return render_template("register.html")
 
@app.route('/search', methods=("POST", "GET"))
def index_age():
    smoke = []
    gender = []
    stroke = []
    bp_ = []
    highcol_ = []
    genhtlh_ = []
    age = []
    value = []
    result = []
    blood_pressure = request.form.get("blood_pressure")
    high_cholesterol = request.form.get("high_cholesterol")
    sex = request.form.get("sex")
    stroke_ = request.form.get("stroke_")
    smoker = request.form.get("smoker")
    general_health = request.form.get("general_health")
    age_ = request.form.get("age_")
    
    if int(age_) < 8:
        age.append(min(list(set(X_['Age']))))

    elif 8<= int(age_) < 16:
        age.append(list(set(X_['Age']))[8])
        
    elif 8<= int(age_) < 16:
        age.append(list(set(X_['Age']))[4])
        
    elif 16<= int(age_) < 34:
        age.append(list(set(X_['Age']))[10])
        
    elif 34<= int(age_) < 42:
        age.append(list(set(X_['Age']))[12])
        
    elif 42<= int(age_) < 50:
        age.append(list(set(X_['Age']))[7])

    elif 50<= int(age_) < 58:
        age.append(list(set(X_['Age']))[5])
        
    elif 58<= int(age_) < 66:
        age.append(list(set(X_['Age']))[1])
        
    elif 66<= int(age_) < 74:
        age.append(list(set(X_['Age']))[9])

    elif 74<= int(age_) < 82:
        age.append(list(set(X_['Age']))[0])

    elif 82<= int(age_) < 90:
        age.append(list(set(X_['Age']))[3])
        
    elif 90<= int(age_) < 98:
        age.append(list(set(X_['Age']))[6])

    elif 98<= int(age_):
        age.append(list(set(X_['Age']))[4])
    
    if smoker == 'Yes':
        smoke.append(list(set(X_['Smoker']))[1])
    else:
        smoke.append(list(set(X_['Smoker']))[0])

    if sex == 'Male':
        gender.append(list(set(X_['Smoker']))[1])
    else:
        gender.append(list(set(X_['Smoker']))[0])

    if stroke_ == 'Yes':
        stroke.append(list(set(X_['Smoker']))[1])
    else:
        stroke.append(list(set(X_['Smoker']))[0])
        
    if blood_pressure == 'Yes':
        bp_.append(list(set(X_['Smoker']))[1])
    else:
        bp_.append(list(set(X_['Smoker']))[0])
        
    if high_cholesterol == 'Yes':
        highcol_.append(list(set(X_['Smoker']))[1])
    else:
        highcol_.append(list(set(X_['Smoker']))[0])

    if general_health == '1':
        genhtlh_.append(list(set(X_['GenHlth']))[2])
    elif general_health == '2':
        genhtlh_.append(list(set(X_['GenHlth']))[1])
    elif general_health == '3':
        genhtlh_.append(list(set(X_['GenHlth']))[0])
    elif general_health == '4':
        genhtlh_.append(list(set(X_['GenHlth']))[3])
    elif general_health == '5':
        genhtlh_.append(list(set(X_['GenHlth']))[4])
        
    
    input_data = pd.DataFrame({
        'Smoker':smoke, 
        'Sex': gender,
        'Stroke': stroke,
        'HighBP': bp_,
        'HighChol': highcol_,
        'GenHlth': genhtlh_,
        'Age': age
        
    })
    new_input = input_data
    new_output = lr.predict(new_input)
    new_output_2 = regr.predict(new_input)
    new_output_3 = dtr.predict(new_input)
    result = (new_output + new_output_2 + new_output_3)/3
    value = result[0]
    
    
    if result[0] > 0.6:
        return render_template('output.html', value=value)
       
    elif 0< result[0] <= 0.6:
       return render_template('output_2.html', value=value)

    elif result[0] == 0:
        return render_template('output_3.html', value=value)
        
@app.route('/menu', methods=("POST", "GET"))
def back_menu():
    return render_template("register.html")

if __name__ == '__main__':
    app.run(debug=True)


#new_input = input_data
#new_output = lr.predict(new_input)
#new_output_2 = regr.predict(new_input)
#new_output_3 = dtr.predict(new_input)
#result = (new_output + new_output_2 + new_output_3)/3
#result 




