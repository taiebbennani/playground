


<html>
<style>
body {
  background-image: url('https://www.worldatlas.com/r/w1200/upload/99/0f/79/untitled-design-2019-04-26t144520-641.jpg');
}
</style>
     <body>
         Do you smoke?:<br>
             <textarea style="width:10%; height: 10em" name="smoke"></textarea>
             <br>
             <input type="submit" value="search">
             <form action="/search" method="POST">
        How old are you?:<br>
            <textarea style="width:10%; height: 10em" name="age"></textarea>
            <br>
            <input type="submit" value="search">
        Do you have a high blood pressure:<br>
            <textarea style="width:10%; height: 10em" name="blood_pressure"></textarea>
            <br>
            <input type="submit" value="search">
        Do you have a high cholesterol:<br>
            <textarea style="width:10%; height: 10em" name="high_cholesterol"></textarea>
            <br>
            <input type="submit" value="search">
        Are you Male or Female?:<br>
            <textarea style="width:10%; height: 10em" name="sex"></textarea>
            <br>
            <input type="submit" value="search">
        In a scale from 1 to 5, how do you consider your general health?:<br>
            <textarea style="width:10%; height: 10em" name="general_health"></textarea>
             <br>
             <input type="submit" value="search">
        Have you ever had a stroke in the past?:<br>
            <textarea style="width:10%; height: 10em" name="stroke_"></textarea>
            <br>
            <input type="submit" value="search">
            <form action="/search" method="POST">
         </form>
     </body>
<html>