
from flask import Flask, request, render_template
import pandas as pd


app = Flask(__name__)


@app.route("/")
def index():
     return render_template("index.html")

@app.route('/search', methods=("POST", "GET"))
def html_table():
    age = request.form["age"]
    blood_pressure = request.form["blood_pressure"]
    high_cholesterol = request.form["high_cholesterol"]
    sex = request.form["sex"]
    stroke_ = request.form["stroke_"]
    smoker = request.form["smoker"]
    general_health = request.form["general_health"]
    if int(age) < 8:
        age.append(min(list(set(X_['Age']))))

    elif 8<= int(age) < 16:
        age.append(list(set(X_['Age']))[8])
        
    elif 8<= int(age) < 16:
        age.append(list(set(X_['Age']))[4])
        
    elif 16<= int(age) < 34:
        age.append(list(set(X_['Age']))[10])
        
    elif 34<= int(age) < 42:
        age.append(list(set(X_['Age']))[12])
        
    elif 42<= int(age) < 50:
        age.append(list(set(X_['Age']))[7])

    elif 50<= int(age) < 58:
        age.append(list(set(X_['Age']))[5])
        
    elif 58<= int(age) < 66:
        age.append(list(set(X_['Age']))[1])
        
    elif 66<= int(age) < 74:
        age.append(list(set(X_['Age']))[9])

    elif 74<= int(age) < 82:
        age.append(list(set(X_['Age']))[0])

    elif 82<= int(age) < 90:
        age.append(list(set(X_['Age']))[3])
        
    elif 90<= int(age) < 98:
        age.append(list(set(X_['Age']))[6])

    elif 98<= int(age):
        age.append(list(set(X_['Age']))[4])
    
    if smoker == 'Yes':
        smoke.append(list(set(X_['Smoker']))[1])
    else:
        smoke.append(list(set(X_['Smoker']))[0])

    if sex == 'Male':
        gender.append(list(set(X_['Smoker']))[1])
    else:
        gender.append(list(set(X_['Smoker']))[0])

    if stroke_ == 'Yes':
        stroke.append(list(set(X_['Smoker']))[1])
    else:
        stroke.append(list(set(X_['Smoker']))[0])
        
    if blood_pressure == 'Yes':
        bp_.append(list(set(X_['Smoker']))[1])
    else:
        bp_.append(list(set(X_['Smoker']))[0])
        
    if high_cholesterol == 'Yes':
        highcol_.append(list(set(X_['Smoker']))[1])
    else:
        highcol_.append(list(set(X_['Smoker']))[0])

    if general_health == '1':
        genhtlh_.append(list(set(X_['GenHlth']))[2])
    elif general_health == '2':
        genhtlh_.append(list(set(X_['GenHlth']))[1])
    elif general_health == '3':
        genhtlh_.append(list(set(X_['GenHlth']))[0])
    elif general_health == '4':
        genhtlh_.append(list(set(X_['GenHlth']))[3])
    elif general_health == '5':
        genhtlh_.append(list(set(X_['GenHlth']))[4])
    
    input_data = pd.DataFrame({
        'Smoker':smoke, 
        'Sex': gender,
        'Stroke': stroke,
        'HighBP': bp_,
        'HighChol': highcol_,
        'GenHlth': genhtlh_,
        'Age': age
        
    })
    
    return render_template('simple.html',  tables=[input_data.to_html(classes='data')], titles=input_data.columns.values)
        
@app.route('/menu', methods=("POST", "GET"))
def back_menu():
    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True)
